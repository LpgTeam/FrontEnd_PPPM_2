<?= $this->include('proposal/p1_proposal'); ?>
<?= $this->include('proposal/p2_proposal'); ?>
<?= $this->include('proposal/p3_proposal'); ?>
<?= $this->include('proposal/p4_proposal'); ?>
<?= $this->include('proposal/p5_proposal'); ?>
